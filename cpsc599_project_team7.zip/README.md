# cpsc599_machineLearningProject


## Team 7
- Abdullah Al-Wadeiah
- Zack Hassan
- Zahra Ghavasieh


## Links

### Data Source
- https://www.kaggle.com/iamhungundji/covid19-symptoms-checker 

### GitHub
- https://github.com/judgyknowitall/cpsc599_machineLearningProject


## Compilation Instructions
Make sure you have python 3 and tensorflow installed on your environment.
And simply run `src/main.py` . 